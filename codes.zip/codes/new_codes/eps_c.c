#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<limits.h>



void main()
  {
    double eps_c, om, alpha;
    
    FILE *fp1;
    fp1 = fopen("ec1.dat","w");
    
    alpha = 0.001;
    
    om = 0.1;
    
    
    for (alpha = 0.0001; alpha <= 1.0;  alpha += 0.001 ){
       
       eps_c = (om*om + 2*om - alpha*alpha)/ ((double) 2*(1+alpha*alpha - om)) ;
     
         printf("%f  %f \n", alpha, eps_c);  
         fprintf(fp1, "%f  %f \n", alpha, eps_c);  
    
    }
    


   }
