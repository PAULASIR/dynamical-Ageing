/********* duffing oscillator with parametric perturbation**************/
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<limits.h>

#define N 30
double omega,c,c1,beta,eps,y[20],x;
void RK4(int,double,double,double[],void (*DGL)(double,double[],double[]));
void DGL(double, double[],double[]);



void main()
{
    int i,j;
    int nn=4;
    double t,h,pi;
    double xmax,xmin,z[40001];
    
  
 //clrscr();
 
 FILE *fp1;
 fp1=fopen("duff1.dat","w");


   y[1]= (float) rand()/(double)RAND_MAX*-2.0+1.0; 
   y[2]= (float) rand()/(double)RAND_MAX*-2.0+1.0;
   y[3]= (float) rand()/(double)RAND_MAX*-2.0+1.0; 
   y[4]= (float) rand()/(double)RAND_MAX*-2.0+1.0;



 omega = 0.5;
 c = 0.0001;
 c1 = 0.001; 
 beta = 0.1;
// scanf("%lf",&eps);
//step size
 h=0.1;
//beta =1.0;


for(eps =0; eps <= 0.05; eps += 0.001 ){
   
 
 xmin=INT_MAX;  xmax=-INT_MAX;
    for(i=1;i<=4000;i++)
	  { 
	    t=h*(double)(i);
	    RK4(nn,h,t,y,DGL);
	    if(i >= 3000)
             {
        //     fprintf(fp1,"%f  %f   %f \n", y[1], y[3], t);
             
            z[i]=y[1];
             if(z[i]>xmax)
              xmax=z[i];
             if(z[i]<xmin)
              xmin=z[i];}       
	      }

   fprintf(fp1,"%f  %f  %f\n", eps, xmax, xmin );
     

 }

	printf("process over!!");
}

//************************RK4 SUBROUTINE*********************************//
void RK4(int nn,double h,double t,double y[20],
	   void (*DGL)(double,double[],double[]))
{
	   int i;
	   double k1[10],k2[10],k3[10],k4[10];
	   double yaux[20];

	   DGL(t,y,k1);
	   for(i=1;i<=nn;i++)
	   {
	   yaux[i]=y[i]+h*k1[i]/2.0;
	   }
	   DGL(t+h/2.0,yaux,k2);
	   for(i=1;i<=nn;i++)
	   {
	   yaux[i]=y[i]+h*k2[i]/2.0;
	   }
	   DGL(t+h/2.0,yaux,k3);
	   for(i=1;i<=nn;i++)
	   {
	   yaux[i]=y[i]+h*k3[i];
	   }
	   DGL(t+h,yaux,k4);
	   for(i=1;i<=nn;i++)
	   {
	      y[i]=y[i]+h*((k1[i]+2*k2[i]+2*k3[i]+k4[i])/6.0);
	   }
}
//*********************FUNCTION SUBROUTINE********************************//
void DGL(double t,double y[20],double F[5])
{ 
 F[1]= y[2]  + eps*(y[3] - y[1]);
 F[2]= -c*y[2] -omega*y[1] - beta*y[1]*y[1]*y[1];
 F[3]= y[4] ;
 F[4]= -c1*y[4] -omega*y[3] - beta*y[3]*y[3]*y[3];
}


