#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<limits.h>



void swap (int *a, int *b)
 {
    int temp = *a;
    *a = *b;
    *b = temp;
 }


/*-----------------------------------------------------------*/
int randomize(int aa[], int nn)
  {
    srand ( time(NULL));
    for (int i = nn-1; i > 0; i--){
        int j = rand() % (i+1);
        swap(&aa[i], &aa[j]);
    }
  }
/*--------------------------------------------------------*/



void main()
{
  int nn= 10;
  int arr[10][10];
  int r;
  int i,j;
  
  
   double p;
  int pc;
  pc =2;
   p = pc/nn;
  printf("%f\n", p);
  
  srand(time(0));
  
   for(int i=0;i< nn; i++){
     for(int j=0;j< nn; j++){
       if((i< pc) && (j< pc))
          arr[i][j] =1;
           else
          arr[i][j] =0;
        printf("%3d \n", arr[i][j]);
         }
        printf("\n");
       }
       
/*       for(int i=0;i< nn; i++){*/
/*        // randomize(arr, nn);*/
/*          // r= rand()/RAND_MAX*-20 + 10;*/
/*          r =rand()%20;*/
/*          printf("%d \n", r);*/
/*       }*/
  
    // int r = rand()% nn + 1;
     
}


















/* #include <stdio.h>*/
/* #include <gsl/gsl_rng.h>*/

/* int main (void)*/
/*  {*/
/*   const gsl_rng_type * T;*/
/*   gsl_rng * r;*/

/*   int i, n = 10;*/

/*   gsl_rng_env_setup();*/

/*     T = gsl_rng_default;*/
/*     r = gsl_rng_alloc (T);*/

/*   for (i = 0; i < n; i++) */
/*     {*/
/*       //double u = gsl_rng_uniform (r);*/
/*        int u =gsl_rng_get(r)% n;*/
/*        printf ("%3d\n", u);*/
/*     }*/

/*   gsl_rng_free (r);*/

/*   return 0;*/
/* }*/
