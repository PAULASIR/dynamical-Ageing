#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<limits.h>





int nn=20;
int pc = 5;

/*void swap (int *a, int *b)*/
/* {*/
/*    int temp = *a;*/
/*    *a = *b;*/
/*    *b = temp;*/
/* }*/


/*-----------------------------------------------------------*/
/*int randomize(int aa[], int nn)*/
/*  {*/
/*    srand ( time(NULL));*/
/*    for (int i = nn-1; i > 0; i--){*/
/*        int j = rand() % (i+1);*/
/*        swap(&aa[i], &aa[j]);*/
/*    }*/
/*  }*/
/*--------------------------------------------------------*/
/*int shuffle(int a[][nn], int nn){*/
/*int i,j;*/
/*  for (int i= 0; i < nn; i++){*/
/*       int r = rand() % nn+1;*/
/*     for (int j = 0; j < nn; j++){*/
/*         int temp =  a[i][j];*/
/*         a[i][j] =  a[r][i];*/
/*         a[r][j] = temp;*/
/*     }*/
/*  }*/
/*}*/

/******************************************/




/*--------------------------------------------------------*/
int shuffle(int a[][nn], int nn){
int i,j;

int rr =0;
int rc=0;

  for (int i= 0; i < nn; i++){
     for (int j = 0; j < nn; j++){
        rr  = rand()%nn;
        rc = rand()%nn;
         int temp =  a[i][j];
         a[i][j] =  a[rr][rc];
         a[rr][rc] = temp;
     }
  }
}

/****************************************/  

void main()
 {
   int i,j;
   int arr[nn][nn], a[nn][nn];
   int deg_sum;

    double p = pc/(float) nn;

    printf("%f\n", p);
  
    
   srand(time(0)); 
   deg_sum =0.0;
  
    for(int i = 0; i < nn; i++){
       for(int j = 0; j < nn; j++){
             if (i <  pc && j< pc)
                arr[i][j] = 1;
             else
                arr[i][j] =0;      
          }    
       } 
    

   for(int i=0; i< nn; i++){
      for(int j=0; j< nn; j++){

         shuffle(arr,nn);         
         printf("%3d" ,arr[i][j]); 
         deg_sum += arr[i][j];
      }
        printf("\n");
    }


        printf("%d \n", deg_sum);

}



// arr[i][j] = rand()%2;
               // if (i*j < pc)


