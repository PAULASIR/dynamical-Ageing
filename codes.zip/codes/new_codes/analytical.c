#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<limits.h>
#include<complex.h>



void main()
 { 
   double complex a,b, c;
   double alpha, om, eps;
   double complex lambda_1, lambda_2, lambda_3, lambda_4;
   
   
   FILE *fp1;
   fp1 = fopen("a1.dat","w");
      
     alpha = 2.0;
     
    // alpha = 3.0;
     om = 0.5;
      
 for(eps = 0; eps <= 2; eps += 0.01) {   
   a = (cpow(alpha,4) + 12*alpha*alpha*eps*eps + 4*alpha*alpha*om + 12*eps*eps*om + 16*om*om);
   b = 2*cpow((-alpha*alpha - 2*om),3) + 108*eps*eps*om*om - 72*(-alpha*alpha)*om*om 
       + 36*eps*(-alpha*alpha - 2*om)*(alpha*alpha*eps + eps*om) + 108*cpow((alpha*alpha*eps + eps*om),2);
       
   c  = (4*csqrt((alpha*alpha + eps*eps +1/3*(-alpha*alpha-2*om) + 2*om + 1.2599207598 *a )) ) / (3*cpow((b + csqrt(-4*a*a*a + b*b)),0.333333333) +  cpow((b + (csqrt(-4*a*a*a + b*b))),0.33333)); 
        
      //  printf("%f   %f  %f\n", creal(a), creal(b), creal(c) );
     
     lambda_1 = (-eps/2 -0.5* csqrt(((alpha*alpha + eps*eps +1/3*(-alpha*alpha- 2*om)+ 2*om * cpow(2,1.259920759)*a))/3*b) -cpow((4*a*a*a + b*b),0.8333) - cpow((b*(4*a*a*a) + b*b),0.833333) + 0.5* csqrt((alpha*alpha + 2*eps*eps +2*om + 1/3*(alpha*alpha+ 2*om) -a/3*b)) - cpow((4*a*a*a + b*b),0.8333)- b*cpow(4*a*a*a + b*b,0.833333) - (-8*eps*eps*eps + 8*eps*(-alpha*alpha -2*om)+ 16*(alpha*alpha)*eps + eps*om)) /  c;
                   
     lambda_2 = (-eps/2 -0.5* csqrt(((alpha*alpha + eps*eps +1/3*(-alpha*alpha- 2*om)+ 2*om * cpow(2,1.259920759)*a))/3*b)  -     cpow((4*a*a*a + b*b),0.8333) - cpow((b*(4*a*a*a) + b*b),0.833333) + 0.5* csqrt((alpha*alpha + 2*eps*eps +2*om + 1/3*(alpha*alpha+ 2*om) -a/3*b)) - cpow((4*a*a*a + b*b),0.8333)- b*cpow(4*a*a*a + b*b,0.833333) - (-8*eps*eps*eps + 8*eps*(-alpha*alpha -2*om)+ 16*(alpha*alpha)*eps + eps*om)) /  c;
 
lambda_3 = (-eps/2 +0.5* csqrt(((alpha*alpha + eps*eps +1/3*(-alpha*alpha- 2*om)+ 2*om * cpow(2,1.259920759)*a))/3*b)  -     cpow((4*a*a*a + b*b),0.8333) - b*cpow((4*a*a*a + b*b),0.833333) + 0.5* csqrt((alpha*alpha + 2*eps*eps +2*om + 1/3*(alpha*alpha+ 2*om) -a/3*b)) - cpow(4*a*a*a + b*b,0.8333)- b*cpow(4*a*a*a + b*b,0.833333) - (-8*eps*eps*eps + 8*eps*(-alpha*alpha -2*om)+ 16*(alpha*alpha)*eps + eps*om)) /  c;

                
lambda_4 = (-eps/2 +0.5* csqrt(((alpha*alpha + eps*eps +1/3*(-alpha*alpha- 2*om)+ 2*om * cpow(2,1.259920759)*a))/3*b)  -     cpow(4*a*a*a + b*b,0.8333) - cpow((b*(4*a*a*a) + b*b),0.833333) - 0.5* csqrt((alpha*alpha + 2*eps*eps +2*om + 1/3*(alpha*alpha+ 2*om) -a/3*b)) - cpow(4*a*a*a + b*b,0.8333)- b*cpow((4*a*a*a) + b*b,0.833333) - (-8*eps*eps*eps + 8*eps*(-alpha*alpha -2*om)+ 16*(alpha*alpha)*eps + eps*om)) / c;        

   
   
   printf("%20.5lf   %20.12lf    %20.12lf i  %20.12lf     %20.12lf i\n", eps, creal(lambda_1)/1000000000, cimag(lambda_1), creal(lambda_3)/1000000000, cimag(lambda_3) );
   
   fprintf(fp1,"%20.5lf   %20.12lf    %20.12lf i  %20.12lf     %20.12lf i\n", eps, creal(lambda_1)/1000000000, cimag(lambda_1), creal(lambda_3)/1000000000, cimag(lambda_3) );
} 
 
  } 
   
   




