#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<limits.h>




void main() {

  FILE *fp1;
  fp1 = fopen("n500_ent.dat", "w");
  
  int n,p, pc;
  double nt_ent;
     
  
  n= 500;
  for(pc = 50; pc<= n+50; pc+= 50 ){
    double p = pc/(float) n;
    nt_ent = p/ (float) n*log(n-1);
     
  fprintf(fp1, "%f  %f \n", p, nt_ent);

}
   










}

