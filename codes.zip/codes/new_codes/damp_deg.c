/*random network with active and inactive nodes*/
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<limits.h>


int nn=20,n=2;
int pc;
double omega, eps;
double y[110][220];
int aa[120], p_mx, ar[120];
double beta;
double z[70000];
int deg_sum;

void RK4(int,int,double,double,double[110][220],
                   void (*DGL)(double,double[110][220],double[110][220]));
void DGL(double, double[110][220],double[110][220]);



/*--------------------------------------------------------*/
int shuffle(int a[][nn], int nn){
int i,j;

int rr =0;
int rc=0;

  for (int i= 0; i < nn; i++){
     for (int j = 0; j < nn; j++){
        rr  = rand()%nn;
        rc = rand()%nn;
         int temp =  a[i][j];
         a[i][j] =  a[rr][rc];
         a[rr][rc] = temp;
     }
  }
}
/****************************************/  




/****************************function to generate random coupling matrices***********/

void assign(int row, int col, int arr[row][col])
{
//    int deg_sum;
    srand(time(0));
    
    for(int i = 0; i < row; i++){
       for(int j = 0; j < col; j++){
             if (i < pc && j< pc)
                arr[i][j] = 1;
             else
                arr[i][j] =0;      
              shuffle(arr,nn);  
          }    
       } 

  // for(int i=0; i< row; i++){
    //  for(int j=0; j< col; j++){
       //  shuffle(arr,nn);         
         //    }
          // }

}
    
/****************************************************/



/*/***********************generating random nodes******************************/

/*// A utility function to swap to integers*/
void swap (int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}



/*-----------------------------------------------------------*/
void randomize ( int aa[], int nn )
  {
    srand ( time(NULL) );
    for (int i = nn-1; i > 0; i--){
        int j = rand() % (i+1);
        swap(&aa[i], &aa[j]);
    }
  }
/*--------------------------------------------------------*/



/************************************************/

void fixArray(int ar[],int nn){
    for (int i = 0; i < nn; i++)
      {
        for (int j = 0; j < nn; j++)
          {
             if (ar[j] == i) {
              int temp = ar[j];
                ar[j] = ar[i];
                ar[i] = temp;
                break;
            }
        }
    }
 
    for (int i = 0; i < nn; i++){
       if (ar[i] != i){
            ar[i] = 0;}
    }
}
/*****************************************************************/


/*double getcor(double z[], int nn)*/
/*{*/

/*    int i,j;*/
/*    */
/*    for(i =0 ; i < nn; i++){*/
/*            printf("%f \n", z[i]); */
/*     }*/
/*    */
/*    return 0;*/
/*}*/
/****************************************************/

void main()
 {
//nn= no 0f oscillators, n=dimension of the model//
double t,h,pi;
double amplitude,vmin,vmax,c_max,c_min;
double x_max,x_min;
double sum, amp;

pc = 12;

 double p = pc/(float) nn;
 printf("%f \n", p);

 int i,j,k;
//srand(time(0));
FILE *fp1, *fp2;
 fp1=fopen("sptime_dt.dat","w");
 fp2=fopen("sp_dt.dat","w");

/*initial conditions*/
for(j=1;j<=nn;j++)
  {
    y[j][1]=(float) rand()/(double)RAND_MAX*-2.0+1.0; 
    y[j][2]=(float) rand()/(double)RAND_MAX*-2.0+1.0;
  }

// fixed parameters
 
 //p_mx=10;
 //eps = 0.0;
  scanf("%d",&p_mx);
  scanf("%lf",&eps); 

   omega = 1.0; 
   beta = 0.5;
   

for(int i=0; i<=nn; i++){ 
      aa[i] = i+1;
    }

 randomize (aa, nn);
 
 for (int i = 0; i < p_mx; i++) {    
           ar[i] = aa[i];
          // printf("%d \n",ar[i]);
        }

  // printf("\n");
 fixArray(ar, nn);


//***time step***//
h=0.1; t=0.0;

x_max= -INT_MAX; x_min=INT_MAX;
//------------------------------------------time loop-----------------------------
  for(k=1;k<=20000;k++)
   {               
      t=h*(double)(k);
      RK4(nn,n,h,t,y,DGL);  

for(j=1;j<=nn;j++)
    {          
/*    leaving transients*/               
	if(k>=19000)
	  {          
/*---------------------------(avg)amplitude calculation---------------------*/       
            // if(k == 19500)
              //  z[j] = y[j][1];                    
         fprintf(fp2,"%d   %f %f \n", j, t, y[j][1]);
/*----------------max & min of the series--------*/
         if(y[j][1]>x_max){x_max=y[j][1];} 
         if(y[j][1]<x_min){x_min=y[j][1];}
         
    
          fprintf(fp1,"%f \t",t); 
          for(i=1;i<=nn;i++)
             fprintf(fp1,"%f \t",y[i][1]);    
            fprintf(fp1," \n"); 

            }
	}    
}

  if(fabs(x_max) - fabs(x_min) <= 0.001)    
      amplitude = fabs(x_max) - fabs(x_min);
                     
  // sum = sum+ amplitude;

   printf("%f \n", amplitude);


   //getcor(z,nn);

printf("process over!!\n");
}
//************************RK4 SUBROUTINE*********************************//
void RK4(int nn,int n,double h,double t,double y[110][220],
	   void (*DGL)(double,double[110][220],double[110][220]))
{
     int i,j;	   


	   double k1[110][220],k2[110][220],k3[110][220],k4[110][220];
	   double yaux[110][220];

	   DGL(t,y,k1);
	   for(j=1;j<=nn;j++)
	   {
            for(i=1;i<=n;i++)
	    yaux[j][i]=y[j][i]+h*k1[j][i]/2.0;
	   }
	   
	   DGL(t+h/2.0,yaux,k2);
	   for(j=1;j<=nn;j++)
	   {
            for(i=1;i<=n;i++)
	    yaux[j][i]=y[j][i]+h*k2[j][i]/2.0;
	   }
	   
	   DGL(t+h/2.0,yaux,k3);
	   for(j=1;j<=nn;j++)
	   {
            for(i=1;i<=n;i++)
	    yaux[j][i]=y[j][i]+h*k3[j][i];
	   }
	   
	   DGL(t+h,yaux,k4);
	   for(j=1;j<=nn;j++)
	   {
             for(i=1;i<=n;i++)
	      y[j][i]=y[j][i]+h*((k1[j][i]+2*k2[j][i]+2*k3[j][i]+k4[j][i])/6.0);
	   }
}
//*********************FUNCTION SUBROUTINE********************************//
void DGL(double t,double y[110][220],double F[110][220])
 {

 int row = nn;
 int col = nn;
 int arr[row][col];
 double alpha;
 
 int i,j;


 double mu; 

 assign(row, col, arr);
  
  for(j = 0; j < nn; j++)
      {                        
       if (j==(int) ar[j])
              {  alpha = 0.1; }
               else
              { alpha = 1e-3;  }  
      // printf(" %d  \n", deg_sum);
   for(i = 0; i < nn; i++) {
    F[j][1]=  y[j][2] + eps*arr[i][j]*(y[i][1] - y[j][1]);                                                                     
    F[j][2]=  -alpha*y[j][2] -omega*y[j][1] - beta*y[j][1]*y[j][1]*y[j][1]; 
      }
   }
}




