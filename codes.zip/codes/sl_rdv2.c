/*random network with active and inactive nodes*/
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<limits.h>


int nn=20,n=2;
double om,eps;
double y[110][220];
int aa[120],p_mx, RMAX, ar[120];
double alpha, eta;

void RK4(int,int,double,double,double[110][220],
                   void (*DGL)(double,double[110][220],double[110][220]));
void DGL(double, double[110][220],double[110][220]);


/****************************function to generate random coupling matrices***********/
void assign(int row, int col, int arr[row][col])
{
    srand(time(0));

    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++) {
            arr[i][j] = rand()%2;
        }
    }
}
/****************************************************/



/***********************generating random nodes*****************************/

// A utility function to swap to integers
void swap (int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

/*-----------------------------------------------------------*/
void randomize ( int aa[], int nn )
  {
    
    srand ( time(NULL) );
    for (int i = nn-1; i > 0; i--){
        int j = rand() % (i+1);
        swap(&aa[i], &aa[j]);
    }
  }
/*--------------------------------------------------------*/



/**********************************************/

void fixArray(int ar[],int nn){
    for (int i = 0; i < nn; i++)
      {
        for (int j = 0; j < nn; j++)
          {
             if (ar[j] == i) {
              int temp = ar[j];
                ar[j] = ar[i];
                ar[i] = temp;
                break;
            }
        }
    }
 
    for (int i = 0; i < nn; i++){
       if (ar[i] != i){
            ar[i] = 0;}
    }
}
/***************************************************************/

void main()
{
//nn= no 0f oscillators, n=dimension of the model//
double t,h,pi;
double z[30000];
double amplitude,vmin,vmax,c_max,c_min;
double x_max,x_min;
double sum, amp;
int RMAX=nn;


int i,j,k;
//srand(time(0));

FILE *fp1, *fp2;
fp1=fopen("sl_t.dat","w");
fp2=fopen("spt.dat","w");

/*initial conditions*/
for(j=1;j<=nn;j++)
 {
  y[j][1]=(float) rand()/(double)RAND_MAX*-2.0+1.0; 
  y[j][2]=(float) rand()/(double)RAND_MAX*-2.0+1.0;
 }

// fixed parameters
 
   p_mx=15;
 //eps = 0.0;
  //scanf("%d",&p_mx);
   scanf("%lf",&eps); 
//  scanf("%lf", &eta);
  
    om    = 0.5; 
    alpha = 0.5;
  
for(int i=0; i<=nn; i++){ 
      aa[i] = i+1;
    }

 randomize (aa, nn);

 
for (int i = 0; i < p_mx; i++)
      {    
           ar[i] = aa[i];
         //  printf("%d \n",ar[i]);
        }

//  printf("\n");
 fixArray(ar, nn);



//***time step***//
h=0.01; t=0.0;

x_max= -INT_MAX; x_min=INT_MAX;
c_max=c_min=0;
vmax= vmin=0;


//------------------------------------------time loop-----------------------------
  for(k=1;k<=10000;k++)
   {               
      t=h*(double)(k);
      RK4(nn,n,h,t,y,DGL);  

for(j=1;j<=nn;j++)
    {          
/*    leaving transients*/               
	if(k>=10)
	  {          
/*---------------------------(avg)amplitude calculation---------------------*/
            z[k]=y[j][1];          
  
       if(z[k]>z[k-1] && z[k]>z[k+1]) 
           {
		     c_max =c_max+1;
		     vmax=vmax+z[k]; 
            }
  	    
          if(z[k]<z[k-1] && z[k]<z[k+1]) 
              {
		       c_min =c_min+1;
		       vmin=vmin+z[k];
              }   


/*----------------max & min of the series--------*/
     //  if(y[1][1]>x_max){x_max=y[1][1];} 
       //if(y[1][1]<x_min){x_min=y[1][1];}

      
             fprintf(fp2,"%d   %f %f \n", j, t, y[j][1]);


    if( z[k] > x_max)
          x_max = z[k];
      if (z[k] < x_min)
         x_min = z[k];

        
       fprintf(fp1,"%f \t",t); 
          for(i=1;i<=nn;i++)
             fprintf(fp1,"%f \t",y[i][1]);    
      fprintf(fp1," \n"); 

        }

        /*  amp = fabs((x_max-x_min));
             if (amp <= 0.0005)
              printf("%d   %f\n", j, amp); */

	}    
}


if(c_max==0||c_min==0)
	 {amplitude = 0.0;}
        else 
          { amplitude= (vmax/c_max) - (vmin/c_min);}

  // sum = sum+ amplitude;

   printf("%f \n", amplitude);


printf("process over!!\n");
}
//************************RK4 SUBROUTINE*********************************//
void RK4(int nn,int n,double h,double t,double y[110][220],
	   void (*DGL)(double,double[110][220],double[110][220]))
{
     int i,j;	   


	   double k1[110][220],k2[110][220],k3[110][220],k4[110][220];
	   double yaux[110][220];

	   DGL(t,y,k1);
	   for(j=1;j<=nn;j++)
	   {
            for(i=1;i<=n;i++)
	    yaux[j][i]=y[j][i]+h*k1[j][i]/2.0;
	   }
	   
	   DGL(t+h/2.0,yaux,k2);
	   for(j=1;j<=nn;j++)
	   {
            for(i=1;i<=n;i++)
	    yaux[j][i]=y[j][i]+h*k2[j][i]/2.0;
	   }
	   
	   DGL(t+h/2.0,yaux,k3);
	   for(j=1;j<=nn;j++)
	   {
            for(i=1;i<=n;i++)
	    yaux[j][i]=y[j][i]+h*k3[j][i];
	   }
	   
	   DGL(t+h,yaux,k4);
	   for(j=1;j<=nn;j++)
	   {
             for(i=1;i<=n;i++)
	      y[j][i]=y[j][i]+h*((k1[j][i]+2*k2[j][i]+2*k3[j][i]+k4[j][i])/6.0);
	   }
}
//*********************FUNCTION SUBROUTINE********************************//
void DGL(double t,double y[110][220],double F[110][220])
 {

 int row = nn;
 int col = nn;
 int arr[row][col];
 

 int i,j;

 double mu; 

 assign(row, col, arr);
 
  
  for (j = 0; j < nn; j++)
      {                        
       if (j==(int) ar[j])
              {
               mu = -0.1; }
           else
              {mu = 0.3; 
                 }  
     //  printf(" %d  %d  %f\n", j, (int) ar[j], mu);
   for (i = 0; i < nn; i++) {   
  F[j][1]=(mu-y[j][1]*y[j][1]-y[j][2]*y[j][2])*y[j][1]-om*y[j][2]+exp(eps)*arr[i][j]*(y[i][1]-y[j][1]);
  F[j][2]=(mu-y[j][1]*y[j][1]-y[j][2]*y[j][2])*y[j][2]+om*y[j][1];
      }
   }
}

























/*((alpha)/pow(eps,eta))



/************ function for gaussian noise******************
double rand_normal(double mean, double stddev)
 {//Box muller method
    static double n2 = 0.0;
    static int n2_cached = 0;
    if (!n2_cached)
     {
        double x, y, r;
        do
        {
            x = 2.0*rand()/RAND_MAX - 1;
            y = 2.0*rand()/RAND_MAX - 1;

            r = x*x + y*y;
        }

        while (r == 0.0 || r > 1.0);
        {
            double d = sqrt(-2.0*log(r)/r);
            double n1 = x*d;
            n2 = y*d;
            double result = n1*stddev + mean;
            n2_cached = 1;
            return result;
        }
    }
    else
    {
        n2_cached = 0;
        return n2*stddev + mean;
    }
}

/*--------------------------------------------------------------------*/


//int *ptr ;

 //int (*ptr)[5] = &aa;
  // ptr = &aa;
         //  ptr = &aa[j];

     //printf("%d \n", *(ptr+10));
                
            //  printf("%d \n", (int) rnd[j]);
             
       //  if (j == *(ptr+10))   


/*for (int i = 0; i < p_mx; i++)
      {    
       //   ptr = &aa[i];
       //    rnd[i] = aa[i];

          rnd[i] = aa[i];

       // printf("%d \n", *ptr);
          //printf("%d \n", ) 
   } */

